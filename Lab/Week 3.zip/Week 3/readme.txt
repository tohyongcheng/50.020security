Script to read list of password, hash them using md5 and store into a new text file.
hash_gen.py

Script to do brute force.
brute.py

Script to read list of password, hash them with 8-bit salt, and store into a new text file.
hash_salt_gen.py

MD5 hashed password list.
passwords_md5.txt

MD5 hashed password list with salting.
passwords_salt.txt

